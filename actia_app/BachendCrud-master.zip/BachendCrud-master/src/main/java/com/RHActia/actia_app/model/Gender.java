package com.RHActia.actia_app.model;


    public enum Gender {
        MALE,
        FEMALE,
        OTHER
    }

